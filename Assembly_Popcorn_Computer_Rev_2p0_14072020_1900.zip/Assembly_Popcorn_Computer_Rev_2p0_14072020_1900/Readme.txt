Board name	: POPCORN COMPUTER
Rev		: 2
Copyright	: Source Parts Inc.


Board Technology information:

No. of Layers		- EIGHT(8)

Board Size 		- 41mm x 60.5mm

Track/Spacing		- 4mil track and 4mil spacing

Via			- 16mil pad and 8mil drill
               
Component		- Mixed Technology

Gerber Format		- RS274-X

=================================================================


List of files in ASSY/ for Assembly
PASTE_TOP.art		-> Gerber, Top Side Solder Paste
PASTE_BOT.art		-> Gerber, Bot Side Solder Paste
ASSEMBLY_TOP.art	-> Gerber, Top Assembly Drawing
ASSEMBLY_BOT.art	-> Gerber, Bot Assembly Drawing
place_txt.txt		-> Components XY Location



Popcorn Computer Rev 2p0_Assembly.pdf -> File for visual compliance



	

